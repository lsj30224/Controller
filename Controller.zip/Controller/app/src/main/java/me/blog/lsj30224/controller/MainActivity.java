package me.blog.lsj30224.controller;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import android.view.View.OnTouchListener;


public class MainActivity extends ActionBarActivity {

    static String SERVERIP = null;
    static boolean ubtncheaker = false;
    static boolean dbtncheaker = false;
    static String message = null;
    static final int SERVERPORT = 59807;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        try {
            ObjectInputStream in = new ObjectInputStream(openFileInput("ip.sj"));
            SERVERIP = in.readObject().toString();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Button ipbtn = (Button) findViewById(R.id.setip);
        ipbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ipintent = new Intent(getApplicationContext(), MainActivity2Activity.class);
                startActivity(ipintent);
            }
        });



        Button ubtn = (Button)findViewById(R.id.ubtn);
        Button dbtn = (Button)findViewById(R.id.dbtn);
        Button lbtn = (Button)findViewById(R.id.lbtn);
        Button rbtn = (Button)findViewById(R.id.rbtn);





        ubtn.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("GO");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("STOP");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        dbtn.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("BACK");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("STOP");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        lbtn.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("LTURN");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("SNP");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        rbtn.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("RTURN");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    try {
                        new DataOutputStream(new Socket(SERVERIP, SERVERPORT).getOutputStream()).writeUTF("SNP");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });







    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}